# !/usr/bin/python
# coding=utf-8
""" depg.py: a helper module for the decryption of PGP files in a Project """
__author__ = 'owl'


import logging
import glob
import getpass
import subprocess


logging.basicConfig(level=logging.INFO)


def decrypt(password=None):
    """ Decrypt all files with a .pgp extension in the current directory without further
        user interaction if a password is specified.
    :param password: """

    # Ask the user to enter a password and hide it.
    if password is None:
        password = getpass.getpass()

    pattern = '*.pgp'
    files = glob.glob(pattern)
    logging.info("Files of type %s found: %s", pattern, len(files))

    pattern = '*.gpg'
    more_files = glob.glob(pattern)
    logging.info("Files of type %s found %s", pattern, len(more_files))

    ext = pattern.strip('*.')

    if more_files is not None:
        files += more_files

    total = files
    filestep = 0

    if files is not None:
        for afile in files:
            logging.info("Decrypting file: %s", afile)
            afile = str(afile)
            outfile = afile.rstrip(ext)
            decrypt_file(afile, outfile, password)
            filestep += 1
        else:
            return logging.info("Decryption complete! exiting...")


def decrypt_file(infile, outfile, phrase):
    """
    :param infile: File to decrypt
    :param outfile: File to write
    :param phrase: Password """

    args = ['gpg.exe', '--passphrase-fd', '0', '--yes', '--batch',
            '--skip-verify', '--quiet', '--always-trust', '--decrypt',
            '--output', outfile, infile]

    try:
        proc = subprocess.Popen(args, stdin=subprocess.PIPE)
        pipe = proc.stdin
        print >> pipe, phrase
        proc.communicate()
        retcode = proc.returncode
        logging.debug("Decryption Return Code %d" % retcode)
        if retcode != 0:
            raise Exception("Decryption failed with nonzero status")
    except OSError, e:
        logging.warn("Decryption Execution Failed. Message Follows")
        logging.warn(e)
        raise


if __name__ == '__Main__':
    decrypt()
    logging.info("Executed %s as a script.", 'depg')
