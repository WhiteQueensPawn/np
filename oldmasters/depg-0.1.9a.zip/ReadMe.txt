DePG | File decryption tool
by mlc based on Ben Stroud's code
Copyright (C) 2014 TargetSmart Communications, LLC.

Currently, the tool only has one purpose and one functionality.
It attempts to decrypt all files with a '*.pgp' or '*.gpg' extension and then write them out to the current directory.
More configuration options will come in the future, and probably a simple reusable GUI as well.*

Usage:

Copy the archive file depg.zip or depg.7z (or whatever format it's in) to a folder containing the files you want to decrypt.

From a python prompt (I use either the default REPL or Ipython), navigate to your directory:

Then type:
	decrypt()

It will ask you to enter a password. Type it and hit <ENTER>

If the password is approved it will attempt to begin decrypting files.


UPDATE: *
	There is now a GUI. Double click or execute gui.pyw
	Usage should be self-explanatory. If not, let me know and I'll write instructions.


Changelog:

0.1.9 - GUI is close to finished. Wrote it in several styles for practice and testing. All should behave the same.

0.1.2 - Refactoring

0.1.1 - Hid the password so it wouldn't show up on screen the whole time
	Rewrote Documentation
	Restructured files and file names
	
0.1.0 - Got it working, more or less.


Bugs:

	BUGREPORT==01 : ipython will hang in some cases once it
			has attached to a file if the file is
			moved or deleted before it finishes.
			

